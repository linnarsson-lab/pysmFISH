# pysmFISH

pysmFISH is a library for the analysis of single molecule fluorescence hybridization (smFISH) experiments.

pysmFISH ([full documentation](http://linnarssonlab.org/pysmFISH/index.html)) include an 
[API](http://linnarssonlab.org/pysmFISH/API/index.html) and a [pipeline](http://linnarssonlab.org/pysmFISH/scripts/index.html)
built to analyse large datasets.

### WARNING
The documentation is still not fully complete and changes will be made frequently and new add ons to the code will be add soon.
