# pysmFISH        [![Build Status](https://travis-ci.org/linnarsson-lab/pysmFISH.svg?branch=master)](https://travis-ci.org/linnarsson-lab/pysmFISH)

pysmFISH is a library for the analysis of cyclic single molecule fluorescence hybridization (smFISH) experiments.

pysmFISH ([full documentation](http://linnarssonlab.org/pysmFISH/index.html)) include an 
[API](http://linnarssonlab.org/pysmFISH/API/index.html) and a [pipeline](http://linnarssonlab.org/pysmFISH/pipeline/index.html)
built to analyse large datasets.

### WARNING
The documentation is still not fully complete and changes will be made frequently and new features to the code will be add soon.